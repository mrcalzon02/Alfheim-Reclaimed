"""Validate the renderer-neutral 47-state connected palette."""
import hashlib
import json
from pathlib import Path
from PIL import Image
from gen_connected_palette import ROOT, build, states47
from material_texture import OUTPUT_SIZE


def main():
    out=build(); states=states47(); assert len(states)==47
    catalog=json.loads(out['tools/connected_palette_catalog.json'])
    assert len(catalog['families'])==42
    assert len(catalog['states'])==47
    tiles=[]
    for family in catalog['families']:
        assert len(family['tiles'])==47,family['id']
        for rel in family['tiles']:
            assert rel in out,rel
            assert (ROOT/rel).read_bytes()==out[rel],rel
            im=Image.open(ROOT/rel)
            assert im.size==(OUTPUT_SIZE,OUTPUT_SIZE) and im.mode=='RGBA',rel
            assert im.getchannel('A').getextrema()==(255,255),rel
            tiles.append(hashlib.sha256(out[rel]).hexdigest())
    assert len(tiles)==42*47
    # Across the full library, palette generation must produce substantial variation.
    assert len(set(tiles))>len(tiles)*.97,(len(set(tiles)),len(tiles))
    print(f'PASS: 42 families × 47 connected states = {len(tiles)} native {OUTPUT_SIZE}x{OUTPUT_SIZE} CTM source tiles; byte-identical')

if __name__=='__main__': main()
